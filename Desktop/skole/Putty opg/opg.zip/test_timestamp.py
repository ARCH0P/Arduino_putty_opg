import serial
import time
from datetime import datetime 

now = datetime.now

timestamp = datetime.timestamp(now)

ser = serial.Serial(
	'COM4', 9600, timeout=0, parity=serial.PARITY_NONE, rtscts=1)

while True:
	
	try:
		s = str(ser.readline(100).decode())
		if s != "":
			f = open("Adgangslogg.txt", "a+")
			print("timestamp =", timestamp)
			f.write(s)
			f.close()
	except:	
		print('ERROR')
time.sleep(1)
